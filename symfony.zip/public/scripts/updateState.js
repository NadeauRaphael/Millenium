$("#formStateUpdate").change(()=>{
    $("#formStateUpdate").submit();
})