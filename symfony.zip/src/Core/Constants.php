<?php

namespace App\Core;

class Constants
{
    public const SHIPPING_COST = 99.99;
    public const TVQ = 5/100;
    public const TPS = 9.975/100;
}
